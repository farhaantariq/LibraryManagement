﻿using LibraryManagement.Data.Model;

namespace LibraryManagement.ViewModel
{
    public class CreateAuthorViewModel
    {
        public Author Author { get; set; }
        public string Referer { get; set; }
    }
}
